package demoapp;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
public class NumberController {

	@RequestMapping("/number/1")
	public String index1() {
		return "One\n";
	}

	@RequestMapping("/number/2")
	public String index2() {
		return "Two\n";
	}

	@RequestMapping("/number/3")
	public String index3() {
		return "Three\n";
	}

}