package demoapp;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
class Employee {

  private @Id @GeneratedValue Long id;
  private String name;
  private String title;
  private String salary;
  private String city;

  Employee() {}

  Employee(String name, String title, String salary, String city) {
    this.name = name;
    this.title = title;
    this.salary = salary;
    this.city = city;
  }

  public Long getId() {
    return this.id;
  }

  public String getName() {
    return this.name;
  }

  public String getTitle() {
    return this.title;
  }

  public String getSalary() {
    return this.salary;
  }

  public String getCity() {
    return this.city;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public void setSalary(String salary) {
    this.salary = salary;
  }

  public void setCity(String city) {
    this.city = city;
  }

  @Override
  public boolean equals(Object o) {

    if (this == o)
      return true;
    if (!(o instanceof Employee))
      return false;
    Employee employee = (Employee) o;
    return
       Objects.equals(this.id, employee.id) &&
       Objects.equals(this.name, employee.name) &&
       Objects.equals(this.title, employee.title) &&
       Objects.equals(this.salary, employee.salary) &&
       Objects.equals(this.city, employee.city);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.name, this.title, this.salary, this.city);
  }
  
  @Override
  public String toString() {
    return "Employee{" +
    "id=" + this.id +
    ",name='" + this.name + '\''  +
    ",title='" + this.title + '\''  +
    ",salary='" + this.salary + '\''  +
    ",city='" + this.city + '\'' + '}';
  }
}
